package cohetes122q2;

import java.time.LocalDate;

public class Cohetes122q2 {

    public static void main(String[] args) {

        EmpresaAeroEspacial empresa = new EmpresaAeroEspacial("Space X");

        cargarCohetes(empresa);

        System.out.println(empresa.cantListosLanzar());

    }

    public static void cargarCohetes(EmpresaAeroEspacial e) {
        Cohete falcon1 = new Cohete(1, "Falcon 1");
        Cohete dragon = new Cohete(2, "Dragon");
        Cohete starship = new Cohete(3, "StarShip");
        Cohete falconHeavy = new Cohete(4, "Falcon Heavy");

        starship.agregarPrueba(new PruebaPropulsion(LocalDate.now(), 7, 80));
        starship.agregarPrueba(new PruebaPropulsion(LocalDate.now(), 6, 90));
        starship.agregarPrueba(new PruebaPropulsion(LocalDate.now(), 10, 60));
        starship.agregarPrueba(new PruebaPropulsion(LocalDate.now(), 8, 70));
        starship.agregarPrueba(new PruebaSistemas(LocalDate.now(), NivelEvaluacion.DEFICIENTE));

        dragon.agregarPrueba(new PruebaPropulsion(LocalDate.now(), 7, 80));
        dragon.agregarPrueba(new PruebaPropulsion(LocalDate.now(), 6, 90));      
        dragon.agregarPrueba(new PruebaSistemas(LocalDate.now(), NivelEvaluacion.EXCELENTE));
        dragon.agregarPrueba(new PruebaSistemas(LocalDate.now(), NivelEvaluacion.DEFICIENTE));

        e.agregarCohete(starship);
        e.agregarCohete(dragon);

    }

}

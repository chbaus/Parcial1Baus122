package cohetes122q2;

public interface Aprobable {

    boolean aprueba();

}

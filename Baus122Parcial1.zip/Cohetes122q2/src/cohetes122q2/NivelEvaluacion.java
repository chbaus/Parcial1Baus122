package cohetes122q2;


public enum NivelEvaluacion {
    DEFICIENTE,
    ACEPTABLE,
    EXCELENTE    
}
